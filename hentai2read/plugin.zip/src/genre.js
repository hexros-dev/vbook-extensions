function execute() {
    return Response.success([
        {title: "Oneshot", input: "https://hentai2read.com/hentai-list/category/Oneshot/", script: "gen.js"},
        {title: "Adult", input: "https://hentai2read.com/hentai-list/category/Adult/", script: "gen.js"},
        {title: "Anal", input: "https://hentai2read.com/hentai-list/category/Anal/", script: "gen.js"},
        {title: "Comedy", input: "https://hentai2read.com/hentai-list/category/Comedy/", script: "gen.js"},
        {title: "Doujinshi", input: "https://hentai2read.com/hentai-list/category/Doujinshi/", script: "gen.js"},
        {title: "Lolicon", input: "https://hentai2read.com/hentai-list/category/Lolicon/", script: "gen.js"},
        {title: "Harem", input: "https://hentai2read.com/hentai-list/category/Harem/", script: "gen.js"},
        {title: "Full Color", input: "https://hentai2read.com/hentai-list/category/Full%20Color/", script: "gen.js"},
        {title: "Incest", input: "https://hentai2read.com/hentai-list/category/Incest/", script: "gen.js"},
        {title: "Uncensored", input: "https://hentai2read.com/hentai-list/category/Un-censored/", script: "gen.js"},
        {title: "Exhibitionism", input: "https://hentai2read.com/hentai-list/category/Exhibitionism/", script: "gen.js"},
        {title: "Big Breasts", input: "https://hentai2read.com/hentai-list/category/Big%20Breasts/", script: "gen.js"},
        {title: "Lactation", input: "https://hentai2read.com/hentai-list/category/Lactation/", script: "gen.js"},
        {title: "Public Nudity", input: "https://hentai2read.com/hentai-list/category/Public%20Nudity/", script: "gen.js"},
        {title: "Public Intercourse", input: "https://hentai2read.com/hentai-list/category/Public%20Intercourse/", script: "gen.js"},
        {title: "Yuri", input: "https://hentai2read.com/hentai-list/category/Yuri/", script: "gen.js"},
    ]);
}